package ReservationHierarchyTests;

public class TestReservation {
}
