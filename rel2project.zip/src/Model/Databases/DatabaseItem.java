package Model.Databases;

public abstract class DatabaseItem {
}
