package Model.Databases;

import java.util.Collection;

public abstract interface Database {

}
